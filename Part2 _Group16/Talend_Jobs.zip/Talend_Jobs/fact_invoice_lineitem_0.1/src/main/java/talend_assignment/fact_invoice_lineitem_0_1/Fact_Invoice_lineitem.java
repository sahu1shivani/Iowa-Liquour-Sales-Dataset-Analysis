
package talend_assignment.fact_invoice_lineitem_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: Fact_Invoice_lineitem Purpose: <br>
 * Description: <br>
 * 
 * @author patil.nis@northeastern.edu
 * @version 8.0.1.20220923_1236-patch
 * @status
 */
public class Fact_Invoice_lineitem implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "Fact_Invoice_lineitem.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(Fact_Invoice_lineitem.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Fact_Invoice_lineitem";
	private final String projectName = "TALEND_ASSIGNMENT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private String cLabel = null;

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_T70BoNT7Ee2jcLY6P8Z-BA", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;

		private String currentComponent = null;
		private String cLabel = null;

		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		private TalendException(Exception e, String errorComponent, String errorComponentLabel,
				final java.util.Map<String, Object> globalMap) {
			this(e, errorComponent, globalMap);
			this.cLabel = errorComponentLabel;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Fact_Invoice_lineitem.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Fact_Invoice_lineitem.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						if (enableLogStash) {
							talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
							talendJobLogProcess(globalMap);
						}
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_row3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class load_FCT_Sales_Invoice_LineitemStruct
			implements routines.system.IPersistableRow<load_FCT_Sales_Invoice_LineitemStruct> {
		final static byte[] commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		static byte[] commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String Invoice_Number;

		public String getInvoice_Number() {
			return this.Invoice_Number;
		}

		public Boolean Invoice_NumberIsNullable() {
			return false;
		}

		public Boolean Invoice_NumberIsKey() {
			return false;
		}

		public Integer Invoice_NumberLength() {
			return 24;
		}

		public Integer Invoice_NumberPrecision() {
			return 0;
		}

		public String Invoice_NumberDefault() {

			return null;

		}

		public String Invoice_NumberComment() {

			return "";

		}

		public String Invoice_NumberPattern() {

			return "";

		}

		public String Invoice_NumberOriginalDbColumnName() {

			return "Invoice_Number";

		}

		public Integer Invoice_Number_LineNo;

		public Integer getInvoice_Number_LineNo() {
			return this.Invoice_Number_LineNo;
		}

		public Boolean Invoice_Number_LineNoIsNullable() {
			return true;
		}

		public Boolean Invoice_Number_LineNoIsKey() {
			return false;
		}

		public Integer Invoice_Number_LineNoLength() {
			return 10;
		}

		public Integer Invoice_Number_LineNoPrecision() {
			return 0;
		}

		public String Invoice_Number_LineNoDefault() {

			return null;

		}

		public String Invoice_Number_LineNoComment() {

			return "";

		}

		public String Invoice_Number_LineNoPattern() {

			return "";

		}

		public String Invoice_Number_LineNoOriginalDbColumnName() {

			return "Invoice_Number_LineNo";

		}

		public String Invoice_Item_Number;

		public String getInvoice_Item_Number() {
			return this.Invoice_Item_Number;
		}

		public Boolean Invoice_Item_NumberIsNullable() {
			return false;
		}

		public Boolean Invoice_Item_NumberIsKey() {
			return true;
		}

		public Integer Invoice_Item_NumberLength() {
			return 24;
		}

		public Integer Invoice_Item_NumberPrecision() {
			return 0;
		}

		public String Invoice_Item_NumberDefault() {

			return null;

		}

		public String Invoice_Item_NumberComment() {

			return "";

		}

		public String Invoice_Item_NumberPattern() {

			return "";

		}

		public String Invoice_Item_NumberOriginalDbColumnName() {

			return "Invoice_Item_Number";

		}

		public int Item_SK;

		public int getItem_SK() {
			return this.Item_SK;
		}

		public Boolean Item_SKIsNullable() {
			return false;
		}

		public Boolean Item_SKIsKey() {
			return false;
		}

		public Integer Item_SKLength() {
			return 10;
		}

		public Integer Item_SKPrecision() {
			return 0;
		}

		public String Item_SKDefault() {

			return null;

		}

		public String Item_SKComment() {

			return "";

		}

		public String Item_SKPattern() {

			return "";

		}

		public String Item_SKOriginalDbColumnName() {

			return "Item_SK";

		}

		public String Item_Number;

		public String getItem_Number() {
			return this.Item_Number;
		}

		public Boolean Item_NumberIsNullable() {
			return true;
		}

		public Boolean Item_NumberIsKey() {
			return false;
		}

		public Integer Item_NumberLength() {
			return 24;
		}

		public Integer Item_NumberPrecision() {
			return 0;
		}

		public String Item_NumberDefault() {

			return null;

		}

		public String Item_NumberComment() {

			return "";

		}

		public String Item_NumberPattern() {

			return "";

		}

		public String Item_NumberOriginalDbColumnName() {

			return "Item_Number";

		}

		public Integer Pack;

		public Integer getPack() {
			return this.Pack;
		}

		public Boolean PackIsNullable() {
			return true;
		}

		public Boolean PackIsKey() {
			return false;
		}

		public Integer PackLength() {
			return 10;
		}

		public Integer PackPrecision() {
			return 0;
		}

		public String PackDefault() {

			return null;

		}

		public String PackComment() {

			return "";

		}

		public String PackPattern() {

			return "";

		}

		public String PackOriginalDbColumnName() {

			return "Pack";

		}

		public Integer Bottle_Volume_ml;

		public Integer getBottle_Volume_ml() {
			return this.Bottle_Volume_ml;
		}

		public Boolean Bottle_Volume_mlIsNullable() {
			return true;
		}

		public Boolean Bottle_Volume_mlIsKey() {
			return false;
		}

		public Integer Bottle_Volume_mlLength() {
			return 10;
		}

		public Integer Bottle_Volume_mlPrecision() {
			return 0;
		}

		public String Bottle_Volume_mlDefault() {

			return null;

		}

		public String Bottle_Volume_mlComment() {

			return "";

		}

		public String Bottle_Volume_mlPattern() {

			return "";

		}

		public String Bottle_Volume_mlOriginalDbColumnName() {

			return "Bottle_Volume_ml";

		}

		public Float State_Bottle_Cost;

		public Float getState_Bottle_Cost() {
			return this.State_Bottle_Cost;
		}

		public Boolean State_Bottle_CostIsNullable() {
			return true;
		}

		public Boolean State_Bottle_CostIsKey() {
			return false;
		}

		public Integer State_Bottle_CostLength() {
			return 19;
		}

		public Integer State_Bottle_CostPrecision() {
			return 4;
		}

		public String State_Bottle_CostDefault() {

			return null;

		}

		public String State_Bottle_CostComment() {

			return "";

		}

		public String State_Bottle_CostPattern() {

			return "";

		}

		public String State_Bottle_CostOriginalDbColumnName() {

			return "State_Bottle_Cost";

		}

		public Float State_Bottle_Retail;

		public Float getState_Bottle_Retail() {
			return this.State_Bottle_Retail;
		}

		public Boolean State_Bottle_RetailIsNullable() {
			return true;
		}

		public Boolean State_Bottle_RetailIsKey() {
			return false;
		}

		public Integer State_Bottle_RetailLength() {
			return 19;
		}

		public Integer State_Bottle_RetailPrecision() {
			return 4;
		}

		public String State_Bottle_RetailDefault() {

			return null;

		}

		public String State_Bottle_RetailComment() {

			return "";

		}

		public String State_Bottle_RetailPattern() {

			return "";

		}

		public String State_Bottle_RetailOriginalDbColumnName() {

			return "State_Bottle_Retail";

		}

		public Integer Bottles_Sold;

		public Integer getBottles_Sold() {
			return this.Bottles_Sold;
		}

		public Boolean Bottles_SoldIsNullable() {
			return true;
		}

		public Boolean Bottles_SoldIsKey() {
			return false;
		}

		public Integer Bottles_SoldLength() {
			return 10;
		}

		public Integer Bottles_SoldPrecision() {
			return 0;
		}

		public String Bottles_SoldDefault() {

			return null;

		}

		public String Bottles_SoldComment() {

			return "";

		}

		public String Bottles_SoldPattern() {

			return "";

		}

		public String Bottles_SoldOriginalDbColumnName() {

			return "Bottles_Sold";

		}

		public Float Sale_Dollars;

		public Float getSale_Dollars() {
			return this.Sale_Dollars;
		}

		public Boolean Sale_DollarsIsNullable() {
			return true;
		}

		public Boolean Sale_DollarsIsKey() {
			return false;
		}

		public Integer Sale_DollarsLength() {
			return 19;
		}

		public Integer Sale_DollarsPrecision() {
			return 4;
		}

		public String Sale_DollarsDefault() {

			return null;

		}

		public String Sale_DollarsComment() {

			return "";

		}

		public String Sale_DollarsPattern() {

			return "";

		}

		public String Sale_DollarsOriginalDbColumnName() {

			return "Sale_Dollars";

		}

		public Float Volume_Sold_Liters;

		public Float getVolume_Sold_Liters() {
			return this.Volume_Sold_Liters;
		}

		public Boolean Volume_Sold_LitersIsNullable() {
			return true;
		}

		public Boolean Volume_Sold_LitersIsKey() {
			return false;
		}

		public Integer Volume_Sold_LitersLength() {
			return 19;
		}

		public Integer Volume_Sold_LitersPrecision() {
			return 4;
		}

		public String Volume_Sold_LitersDefault() {

			return null;

		}

		public String Volume_Sold_LitersComment() {

			return "";

		}

		public String Volume_Sold_LitersPattern() {

			return "";

		}

		public String Volume_Sold_LitersOriginalDbColumnName() {

			return "Volume_Sold_Liters";

		}

		public Float Volume_Sold_Gallons;

		public Float getVolume_Sold_Gallons() {
			return this.Volume_Sold_Gallons;
		}

		public Boolean Volume_Sold_GallonsIsNullable() {
			return true;
		}

		public Boolean Volume_Sold_GallonsIsKey() {
			return false;
		}

		public Integer Volume_Sold_GallonsLength() {
			return 19;
		}

		public Integer Volume_Sold_GallonsPrecision() {
			return 4;
		}

		public String Volume_Sold_GallonsDefault() {

			return null;

		}

		public String Volume_Sold_GallonsComment() {

			return "";

		}

		public String Volume_Sold_GallonsPattern() {

			return "";

		}

		public String Volume_Sold_GallonsOriginalDbColumnName() {

			return "Volume_Sold_Gallons";

		}

		public String DI_JobID;

		public String getDI_JobID() {
			return this.DI_JobID;
		}

		public Boolean DI_JobIDIsNullable() {
			return true;
		}

		public Boolean DI_JobIDIsKey() {
			return false;
		}

		public Integer DI_JobIDLength() {
			return 20;
		}

		public Integer DI_JobIDPrecision() {
			return 0;
		}

		public String DI_JobIDDefault() {

			return null;

		}

		public String DI_JobIDComment() {

			return "";

		}

		public String DI_JobIDPattern() {

			return "";

		}

		public String DI_JobIDOriginalDbColumnName() {

			return "DI_JobID";

		}

		public java.util.Date DI_CreateDate;

		public java.util.Date getDI_CreateDate() {
			return this.DI_CreateDate;
		}

		public Boolean DI_CreateDateIsNullable() {
			return false;
		}

		public Boolean DI_CreateDateIsKey() {
			return false;
		}

		public Integer DI_CreateDateLength() {
			return 23;
		}

		public Integer DI_CreateDatePrecision() {
			return 3;
		}

		public String DI_CreateDateDefault() {

			return "'getdate()'";

		}

		public String DI_CreateDateComment() {

			return "";

		}

		public String DI_CreateDatePattern() {

			return "MM/dd/yyyy";

		}

		public String DI_CreateDateOriginalDbColumnName() {

			return "DI_CreateDate";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result
						+ ((this.Invoice_Item_Number == null) ? 0 : this.Invoice_Item_Number.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final load_FCT_Sales_Invoice_LineitemStruct other = (load_FCT_Sales_Invoice_LineitemStruct) obj;

			if (this.Invoice_Item_Number == null) {
				if (other.Invoice_Item_Number != null)
					return false;

			} else if (!this.Invoice_Item_Number.equals(other.Invoice_Item_Number))

				return false;

			return true;
		}

		public void copyDataTo(load_FCT_Sales_Invoice_LineitemStruct other) {

			other.Invoice_Number = this.Invoice_Number;
			other.Invoice_Number_LineNo = this.Invoice_Number_LineNo;
			other.Invoice_Item_Number = this.Invoice_Item_Number;
			other.Item_SK = this.Item_SK;
			other.Item_Number = this.Item_Number;
			other.Pack = this.Pack;
			other.Bottle_Volume_ml = this.Bottle_Volume_ml;
			other.State_Bottle_Cost = this.State_Bottle_Cost;
			other.State_Bottle_Retail = this.State_Bottle_Retail;
			other.Bottles_Sold = this.Bottles_Sold;
			other.Sale_Dollars = this.Sale_Dollars;
			other.Volume_Sold_Liters = this.Volume_Sold_Liters;
			other.Volume_Sold_Gallons = this.Volume_Sold_Gallons;
			other.DI_JobID = this.DI_JobID;
			other.DI_CreateDate = this.DI_CreateDate;

		}

		public void copyKeysDataTo(load_FCT_Sales_Invoice_LineitemStruct other) {

			other.Invoice_Item_Number = this.Invoice_Item_Number;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Number = readString(dis);

					this.Invoice_Number_LineNo = readInteger(dis);

					this.Invoice_Item_Number = readString(dis);

					this.Item_SK = dis.readInt();

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume_ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale_Dollars = null;
					} else {
						this.Sale_Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold_Liters = null;
					} else {
						this.Volume_Sold_Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold_Gallons = null;
					} else {
						this.Volume_Sold_Gallons = dis.readFloat();
					}

					this.DI_JobID = readString(dis);

					this.DI_CreateDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Number = readString(dis);

					this.Invoice_Number_LineNo = readInteger(dis);

					this.Invoice_Item_Number = readString(dis);

					this.Item_SK = dis.readInt();

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume_ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale_Dollars = null;
					} else {
						this.Sale_Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold_Liters = null;
					} else {
						this.Volume_Sold_Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold_Gallons = null;
					} else {
						this.Volume_Sold_Gallons = dis.readFloat();
					}

					this.DI_JobID = readString(dis);

					this.DI_CreateDate = readDate(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Invoice_Number, dos);

				// Integer

				writeInteger(this.Invoice_Number_LineNo, dos);

				// String

				writeString(this.Invoice_Item_Number, dos);

				// int

				dos.writeInt(this.Item_SK);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume_ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale_Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale_Dollars);
				}

				// Float

				if (this.Volume_Sold_Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold_Liters);
				}

				// Float

				if (this.Volume_Sold_Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold_Gallons);
				}

				// String

				writeString(this.DI_JobID, dos);

				// java.util.Date

				writeDate(this.DI_CreateDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Invoice_Number, dos);

				// Integer

				writeInteger(this.Invoice_Number_LineNo, dos);

				// String

				writeString(this.Invoice_Item_Number, dos);

				// int

				dos.writeInt(this.Item_SK);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume_ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale_Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale_Dollars);
				}

				// Float

				if (this.Volume_Sold_Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold_Liters);
				}

				// Float

				if (this.Volume_Sold_Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold_Gallons);
				}

				// String

				writeString(this.DI_JobID, dos);

				// java.util.Date

				writeDate(this.DI_CreateDate, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Invoice_Number=" + Invoice_Number);
			sb.append(",Invoice_Number_LineNo=" + String.valueOf(Invoice_Number_LineNo));
			sb.append(",Invoice_Item_Number=" + Invoice_Item_Number);
			sb.append(",Item_SK=" + String.valueOf(Item_SK));
			sb.append(",Item_Number=" + Item_Number);
			sb.append(",Pack=" + String.valueOf(Pack));
			sb.append(",Bottle_Volume_ml=" + String.valueOf(Bottle_Volume_ml));
			sb.append(",State_Bottle_Cost=" + String.valueOf(State_Bottle_Cost));
			sb.append(",State_Bottle_Retail=" + String.valueOf(State_Bottle_Retail));
			sb.append(",Bottles_Sold=" + String.valueOf(Bottles_Sold));
			sb.append(",Sale_Dollars=" + String.valueOf(Sale_Dollars));
			sb.append(",Volume_Sold_Liters=" + String.valueOf(Volume_Sold_Liters));
			sb.append(",Volume_Sold_Gallons=" + String.valueOf(Volume_Sold_Gallons));
			sb.append(",DI_JobID=" + DI_JobID);
			sb.append(",DI_CreateDate=" + String.valueOf(DI_CreateDate));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Invoice_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Number);
			}

			sb.append("|");

			if (Invoice_Number_LineNo == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Number_LineNo);
			}

			sb.append("|");

			if (Invoice_Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Item_Number);
			}

			sb.append("|");

			sb.append(Item_SK);

			sb.append("|");

			if (Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Item_Number);
			}

			sb.append("|");

			if (Pack == null) {
				sb.append("<null>");
			} else {
				sb.append(Pack);
			}

			sb.append("|");

			if (Bottle_Volume_ml == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottle_Volume_ml);
			}

			sb.append("|");

			if (State_Bottle_Cost == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Cost);
			}

			sb.append("|");

			if (State_Bottle_Retail == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Retail);
			}

			sb.append("|");

			if (Bottles_Sold == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottles_Sold);
			}

			sb.append("|");

			if (Sale_Dollars == null) {
				sb.append("<null>");
			} else {
				sb.append(Sale_Dollars);
			}

			sb.append("|");

			if (Volume_Sold_Liters == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold_Liters);
			}

			sb.append("|");

			if (Volume_Sold_Gallons == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold_Gallons);
			}

			sb.append("|");

			if (DI_JobID == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_JobID);
			}

			sb.append("|");

			if (DI_CreateDate == null) {
				sb.append("<null>");
			} else {
				sb.append(DI_CreateDate);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(load_FCT_Sales_Invoice_LineitemStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.Invoice_Item_Number, other.Invoice_Item_Number);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		static byte[] commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];

		public String Invoice_Item_Number;

		public String getInvoice_Item_Number() {
			return this.Invoice_Item_Number;
		}

		public Boolean Invoice_Item_NumberIsNullable() {
			return true;
		}

		public Boolean Invoice_Item_NumberIsKey() {
			return false;
		}

		public Integer Invoice_Item_NumberLength() {
			return 254;
		}

		public Integer Invoice_Item_NumberPrecision() {
			return 0;
		}

		public String Invoice_Item_NumberDefault() {

			return null;

		}

		public String Invoice_Item_NumberComment() {

			return "";

		}

		public String Invoice_Item_NumberPattern() {

			return "";

		}

		public String Invoice_Item_NumberOriginalDbColumnName() {

			return "Invoice_Item_Number";

		}

		public String Item_Number;

		public String getItem_Number() {
			return this.Item_Number;
		}

		public Boolean Item_NumberIsNullable() {
			return true;
		}

		public Boolean Item_NumberIsKey() {
			return false;
		}

		public Integer Item_NumberLength() {
			return 254;
		}

		public Integer Item_NumberPrecision() {
			return 0;
		}

		public String Item_NumberDefault() {

			return null;

		}

		public String Item_NumberComment() {

			return "";

		}

		public String Item_NumberPattern() {

			return "";

		}

		public String Item_NumberOriginalDbColumnName() {

			return "Item_Number";

		}

		public Integer Pack;

		public Integer getPack() {
			return this.Pack;
		}

		public Boolean PackIsNullable() {
			return true;
		}

		public Boolean PackIsKey() {
			return false;
		}

		public Integer PackLength() {
			return 10;
		}

		public Integer PackPrecision() {
			return 0;
		}

		public String PackDefault() {

			return null;

		}

		public String PackComment() {

			return "";

		}

		public String PackPattern() {

			return "";

		}

		public String PackOriginalDbColumnName() {

			return "Pack";

		}

		public Integer Bottle_Volume__ml;

		public Integer getBottle_Volume__ml() {
			return this.Bottle_Volume__ml;
		}

		public Boolean Bottle_Volume__mlIsNullable() {
			return true;
		}

		public Boolean Bottle_Volume__mlIsKey() {
			return false;
		}

		public Integer Bottle_Volume__mlLength() {
			return 10;
		}

		public Integer Bottle_Volume__mlPrecision() {
			return 0;
		}

		public String Bottle_Volume__mlDefault() {

			return null;

		}

		public String Bottle_Volume__mlComment() {

			return "";

		}

		public String Bottle_Volume__mlPattern() {

			return "";

		}

		public String Bottle_Volume__mlOriginalDbColumnName() {

			return "Bottle_Volume__ml";

		}

		public Float State_Bottle_Cost;

		public Float getState_Bottle_Cost() {
			return this.State_Bottle_Cost;
		}

		public Boolean State_Bottle_CostIsNullable() {
			return true;
		}

		public Boolean State_Bottle_CostIsKey() {
			return false;
		}

		public Integer State_Bottle_CostLength() {
			return 24;
		}

		public Integer State_Bottle_CostPrecision() {
			return 0;
		}

		public String State_Bottle_CostDefault() {

			return null;

		}

		public String State_Bottle_CostComment() {

			return "";

		}

		public String State_Bottle_CostPattern() {

			return "";

		}

		public String State_Bottle_CostOriginalDbColumnName() {

			return "State_Bottle_Cost";

		}

		public Float State_Bottle_Retail;

		public Float getState_Bottle_Retail() {
			return this.State_Bottle_Retail;
		}

		public Boolean State_Bottle_RetailIsNullable() {
			return true;
		}

		public Boolean State_Bottle_RetailIsKey() {
			return false;
		}

		public Integer State_Bottle_RetailLength() {
			return 24;
		}

		public Integer State_Bottle_RetailPrecision() {
			return 0;
		}

		public String State_Bottle_RetailDefault() {

			return null;

		}

		public String State_Bottle_RetailComment() {

			return "";

		}

		public String State_Bottle_RetailPattern() {

			return "";

		}

		public String State_Bottle_RetailOriginalDbColumnName() {

			return "State_Bottle_Retail";

		}

		public Integer Bottles_Sold;

		public Integer getBottles_Sold() {
			return this.Bottles_Sold;
		}

		public Boolean Bottles_SoldIsNullable() {
			return true;
		}

		public Boolean Bottles_SoldIsKey() {
			return false;
		}

		public Integer Bottles_SoldLength() {
			return 10;
		}

		public Integer Bottles_SoldPrecision() {
			return 0;
		}

		public String Bottles_SoldDefault() {

			return null;

		}

		public String Bottles_SoldComment() {

			return "";

		}

		public String Bottles_SoldPattern() {

			return "";

		}

		public String Bottles_SoldOriginalDbColumnName() {

			return "Bottles_Sold";

		}

		public Float Sale__Dollars;

		public Float getSale__Dollars() {
			return this.Sale__Dollars;
		}

		public Boolean Sale__DollarsIsNullable() {
			return true;
		}

		public Boolean Sale__DollarsIsKey() {
			return false;
		}

		public Integer Sale__DollarsLength() {
			return 24;
		}

		public Integer Sale__DollarsPrecision() {
			return 0;
		}

		public String Sale__DollarsDefault() {

			return null;

		}

		public String Sale__DollarsComment() {

			return "";

		}

		public String Sale__DollarsPattern() {

			return "";

		}

		public String Sale__DollarsOriginalDbColumnName() {

			return "Sale__Dollars";

		}

		public Float Volume_Sold__Liters;

		public Float getVolume_Sold__Liters() {
			return this.Volume_Sold__Liters;
		}

		public Boolean Volume_Sold__LitersIsNullable() {
			return true;
		}

		public Boolean Volume_Sold__LitersIsKey() {
			return false;
		}

		public Integer Volume_Sold__LitersLength() {
			return 24;
		}

		public Integer Volume_Sold__LitersPrecision() {
			return 0;
		}

		public String Volume_Sold__LitersDefault() {

			return null;

		}

		public String Volume_Sold__LitersComment() {

			return "";

		}

		public String Volume_Sold__LitersPattern() {

			return "";

		}

		public String Volume_Sold__LitersOriginalDbColumnName() {

			return "Volume_Sold__Liters";

		}

		public Float Volume_Sold__Gallons;

		public Float getVolume_Sold__Gallons() {
			return this.Volume_Sold__Gallons;
		}

		public Boolean Volume_Sold__GallonsIsNullable() {
			return true;
		}

		public Boolean Volume_Sold__GallonsIsKey() {
			return false;
		}

		public Integer Volume_Sold__GallonsLength() {
			return 24;
		}

		public Integer Volume_Sold__GallonsPrecision() {
			return 0;
		}

		public String Volume_Sold__GallonsDefault() {

			return null;

		}

		public String Volume_Sold__GallonsComment() {

			return "";

		}

		public String Volume_Sold__GallonsPattern() {

			return "";

		}

		public String Volume_Sold__GallonsOriginalDbColumnName() {

			return "Volume_Sold__Gallons";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Item_Number = readString(dis);

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume__ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale__Dollars = null;
					} else {
						this.Sale__Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Liters = null;
					} else {
						this.Volume_Sold__Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Gallons = null;
					} else {
						this.Volume_Sold__Gallons = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Item_Number = readString(dis);

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume__ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale__Dollars = null;
					} else {
						this.Sale__Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Liters = null;
					} else {
						this.Volume_Sold__Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Gallons = null;
					} else {
						this.Volume_Sold__Gallons = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Invoice_Item_Number, dos);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume__ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale__Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale__Dollars);
				}

				// Float

				if (this.Volume_Sold__Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Liters);
				}

				// Float

				if (this.Volume_Sold__Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Gallons);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Invoice_Item_Number, dos);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume__ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale__Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale__Dollars);
				}

				// Float

				if (this.Volume_Sold__Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Liters);
				}

				// Float

				if (this.Volume_Sold__Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Gallons);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Invoice_Item_Number=" + Invoice_Item_Number);
			sb.append(",Item_Number=" + Item_Number);
			sb.append(",Pack=" + String.valueOf(Pack));
			sb.append(",Bottle_Volume__ml=" + String.valueOf(Bottle_Volume__ml));
			sb.append(",State_Bottle_Cost=" + String.valueOf(State_Bottle_Cost));
			sb.append(",State_Bottle_Retail=" + String.valueOf(State_Bottle_Retail));
			sb.append(",Bottles_Sold=" + String.valueOf(Bottles_Sold));
			sb.append(",Sale__Dollars=" + String.valueOf(Sale__Dollars));
			sb.append(",Volume_Sold__Liters=" + String.valueOf(Volume_Sold__Liters));
			sb.append(",Volume_Sold__Gallons=" + String.valueOf(Volume_Sold__Gallons));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Invoice_Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Item_Number);
			}

			sb.append("|");

			if (Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Item_Number);
			}

			sb.append("|");

			if (Pack == null) {
				sb.append("<null>");
			} else {
				sb.append(Pack);
			}

			sb.append("|");

			if (Bottle_Volume__ml == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottle_Volume__ml);
			}

			sb.append("|");

			if (State_Bottle_Cost == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Cost);
			}

			sb.append("|");

			if (State_Bottle_Retail == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Retail);
			}

			sb.append("|");

			if (Bottles_Sold == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottles_Sold);
			}

			sb.append("|");

			if (Sale__Dollars == null) {
				sb.append("<null>");
			} else {
				sb.append(Sale__Dollars);
			}

			sb.append("|");

			if (Volume_Sold__Liters == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold__Liters);
			}

			sb.append("|");

			if (Volume_Sold__Gallons == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold__Gallons);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tDBInput_1Struct implements routines.system.IPersistableRow<after_tDBInput_1Struct> {
		final static byte[] commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		static byte[] commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];

		public String Invoice_Item_Number;

		public String getInvoice_Item_Number() {
			return this.Invoice_Item_Number;
		}

		public Boolean Invoice_Item_NumberIsNullable() {
			return true;
		}

		public Boolean Invoice_Item_NumberIsKey() {
			return false;
		}

		public Integer Invoice_Item_NumberLength() {
			return 254;
		}

		public Integer Invoice_Item_NumberPrecision() {
			return 0;
		}

		public String Invoice_Item_NumberDefault() {

			return null;

		}

		public String Invoice_Item_NumberComment() {

			return "";

		}

		public String Invoice_Item_NumberPattern() {

			return "";

		}

		public String Invoice_Item_NumberOriginalDbColumnName() {

			return "Invoice_Item_Number";

		}

		public String Item_Number;

		public String getItem_Number() {
			return this.Item_Number;
		}

		public Boolean Item_NumberIsNullable() {
			return true;
		}

		public Boolean Item_NumberIsKey() {
			return false;
		}

		public Integer Item_NumberLength() {
			return 254;
		}

		public Integer Item_NumberPrecision() {
			return 0;
		}

		public String Item_NumberDefault() {

			return null;

		}

		public String Item_NumberComment() {

			return "";

		}

		public String Item_NumberPattern() {

			return "";

		}

		public String Item_NumberOriginalDbColumnName() {

			return "Item_Number";

		}

		public Integer Pack;

		public Integer getPack() {
			return this.Pack;
		}

		public Boolean PackIsNullable() {
			return true;
		}

		public Boolean PackIsKey() {
			return false;
		}

		public Integer PackLength() {
			return 10;
		}

		public Integer PackPrecision() {
			return 0;
		}

		public String PackDefault() {

			return null;

		}

		public String PackComment() {

			return "";

		}

		public String PackPattern() {

			return "";

		}

		public String PackOriginalDbColumnName() {

			return "Pack";

		}

		public Integer Bottle_Volume__ml;

		public Integer getBottle_Volume__ml() {
			return this.Bottle_Volume__ml;
		}

		public Boolean Bottle_Volume__mlIsNullable() {
			return true;
		}

		public Boolean Bottle_Volume__mlIsKey() {
			return false;
		}

		public Integer Bottle_Volume__mlLength() {
			return 10;
		}

		public Integer Bottle_Volume__mlPrecision() {
			return 0;
		}

		public String Bottle_Volume__mlDefault() {

			return null;

		}

		public String Bottle_Volume__mlComment() {

			return "";

		}

		public String Bottle_Volume__mlPattern() {

			return "";

		}

		public String Bottle_Volume__mlOriginalDbColumnName() {

			return "Bottle_Volume__ml";

		}

		public Float State_Bottle_Cost;

		public Float getState_Bottle_Cost() {
			return this.State_Bottle_Cost;
		}

		public Boolean State_Bottle_CostIsNullable() {
			return true;
		}

		public Boolean State_Bottle_CostIsKey() {
			return false;
		}

		public Integer State_Bottle_CostLength() {
			return 24;
		}

		public Integer State_Bottle_CostPrecision() {
			return 0;
		}

		public String State_Bottle_CostDefault() {

			return null;

		}

		public String State_Bottle_CostComment() {

			return "";

		}

		public String State_Bottle_CostPattern() {

			return "";

		}

		public String State_Bottle_CostOriginalDbColumnName() {

			return "State_Bottle_Cost";

		}

		public Float State_Bottle_Retail;

		public Float getState_Bottle_Retail() {
			return this.State_Bottle_Retail;
		}

		public Boolean State_Bottle_RetailIsNullable() {
			return true;
		}

		public Boolean State_Bottle_RetailIsKey() {
			return false;
		}

		public Integer State_Bottle_RetailLength() {
			return 24;
		}

		public Integer State_Bottle_RetailPrecision() {
			return 0;
		}

		public String State_Bottle_RetailDefault() {

			return null;

		}

		public String State_Bottle_RetailComment() {

			return "";

		}

		public String State_Bottle_RetailPattern() {

			return "";

		}

		public String State_Bottle_RetailOriginalDbColumnName() {

			return "State_Bottle_Retail";

		}

		public Integer Bottles_Sold;

		public Integer getBottles_Sold() {
			return this.Bottles_Sold;
		}

		public Boolean Bottles_SoldIsNullable() {
			return true;
		}

		public Boolean Bottles_SoldIsKey() {
			return false;
		}

		public Integer Bottles_SoldLength() {
			return 10;
		}

		public Integer Bottles_SoldPrecision() {
			return 0;
		}

		public String Bottles_SoldDefault() {

			return null;

		}

		public String Bottles_SoldComment() {

			return "";

		}

		public String Bottles_SoldPattern() {

			return "";

		}

		public String Bottles_SoldOriginalDbColumnName() {

			return "Bottles_Sold";

		}

		public Float Sale__Dollars;

		public Float getSale__Dollars() {
			return this.Sale__Dollars;
		}

		public Boolean Sale__DollarsIsNullable() {
			return true;
		}

		public Boolean Sale__DollarsIsKey() {
			return false;
		}

		public Integer Sale__DollarsLength() {
			return 24;
		}

		public Integer Sale__DollarsPrecision() {
			return 0;
		}

		public String Sale__DollarsDefault() {

			return null;

		}

		public String Sale__DollarsComment() {

			return "";

		}

		public String Sale__DollarsPattern() {

			return "";

		}

		public String Sale__DollarsOriginalDbColumnName() {

			return "Sale__Dollars";

		}

		public Float Volume_Sold__Liters;

		public Float getVolume_Sold__Liters() {
			return this.Volume_Sold__Liters;
		}

		public Boolean Volume_Sold__LitersIsNullable() {
			return true;
		}

		public Boolean Volume_Sold__LitersIsKey() {
			return false;
		}

		public Integer Volume_Sold__LitersLength() {
			return 24;
		}

		public Integer Volume_Sold__LitersPrecision() {
			return 0;
		}

		public String Volume_Sold__LitersDefault() {

			return null;

		}

		public String Volume_Sold__LitersComment() {

			return "";

		}

		public String Volume_Sold__LitersPattern() {

			return "";

		}

		public String Volume_Sold__LitersOriginalDbColumnName() {

			return "Volume_Sold__Liters";

		}

		public Float Volume_Sold__Gallons;

		public Float getVolume_Sold__Gallons() {
			return this.Volume_Sold__Gallons;
		}

		public Boolean Volume_Sold__GallonsIsNullable() {
			return true;
		}

		public Boolean Volume_Sold__GallonsIsKey() {
			return false;
		}

		public Integer Volume_Sold__GallonsLength() {
			return 24;
		}

		public Integer Volume_Sold__GallonsPrecision() {
			return 0;
		}

		public String Volume_Sold__GallonsDefault() {

			return null;

		}

		public String Volume_Sold__GallonsComment() {

			return "";

		}

		public String Volume_Sold__GallonsPattern() {

			return "";

		}

		public String Volume_Sold__GallonsOriginalDbColumnName() {

			return "Volume_Sold__Gallons";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Item_Number = readString(dis);

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume__ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale__Dollars = null;
					} else {
						this.Sale__Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Liters = null;
					} else {
						this.Volume_Sold__Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Gallons = null;
					} else {
						this.Volume_Sold__Gallons = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Item_Number = readString(dis);

					this.Item_Number = readString(dis);

					this.Pack = readInteger(dis);

					this.Bottle_Volume__ml = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Cost = null;
					} else {
						this.State_Bottle_Cost = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.State_Bottle_Retail = null;
					} else {
						this.State_Bottle_Retail = dis.readFloat();
					}

					this.Bottles_Sold = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.Sale__Dollars = null;
					} else {
						this.Sale__Dollars = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Liters = null;
					} else {
						this.Volume_Sold__Liters = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.Volume_Sold__Gallons = null;
					} else {
						this.Volume_Sold__Gallons = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Invoice_Item_Number, dos);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume__ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale__Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale__Dollars);
				}

				// Float

				if (this.Volume_Sold__Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Liters);
				}

				// Float

				if (this.Volume_Sold__Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Gallons);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Invoice_Item_Number, dos);

				// String

				writeString(this.Item_Number, dos);

				// Integer

				writeInteger(this.Pack, dos);

				// Integer

				writeInteger(this.Bottle_Volume__ml, dos);

				// Float

				if (this.State_Bottle_Cost == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Cost);
				}

				// Float

				if (this.State_Bottle_Retail == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.State_Bottle_Retail);
				}

				// Integer

				writeInteger(this.Bottles_Sold, dos);

				// Float

				if (this.Sale__Dollars == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Sale__Dollars);
				}

				// Float

				if (this.Volume_Sold__Liters == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Liters);
				}

				// Float

				if (this.Volume_Sold__Gallons == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.Volume_Sold__Gallons);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Invoice_Item_Number=" + Invoice_Item_Number);
			sb.append(",Item_Number=" + Item_Number);
			sb.append(",Pack=" + String.valueOf(Pack));
			sb.append(",Bottle_Volume__ml=" + String.valueOf(Bottle_Volume__ml));
			sb.append(",State_Bottle_Cost=" + String.valueOf(State_Bottle_Cost));
			sb.append(",State_Bottle_Retail=" + String.valueOf(State_Bottle_Retail));
			sb.append(",Bottles_Sold=" + String.valueOf(Bottles_Sold));
			sb.append(",Sale__Dollars=" + String.valueOf(Sale__Dollars));
			sb.append(",Volume_Sold__Liters=" + String.valueOf(Volume_Sold__Liters));
			sb.append(",Volume_Sold__Gallons=" + String.valueOf(Volume_Sold__Gallons));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Invoice_Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Item_Number);
			}

			sb.append("|");

			if (Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Item_Number);
			}

			sb.append("|");

			if (Pack == null) {
				sb.append("<null>");
			} else {
				sb.append(Pack);
			}

			sb.append("|");

			if (Bottle_Volume__ml == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottle_Volume__ml);
			}

			sb.append("|");

			if (State_Bottle_Cost == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Cost);
			}

			sb.append("|");

			if (State_Bottle_Retail == null) {
				sb.append("<null>");
			} else {
				sb.append(State_Bottle_Retail);
			}

			sb.append("|");

			if (Bottles_Sold == null) {
				sb.append("<null>");
			} else {
				sb.append(Bottles_Sold);
			}

			sb.append("|");

			if (Sale__Dollars == null) {
				sb.append("<null>");
			} else {
				sb.append(Sale__Dollars);
			}

			sb.append("|");

			if (Volume_Sold__Liters == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold__Liters);
			}

			sb.append("|");

			if (Volume_Sold__Gallons == null) {
				sb.append("<null>");
			} else {
				sb.append(Volume_Sold__Gallons);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tDBInput_1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tDBInput_2Process(globalMap);
				tDBInput_3Process(globalMap);

				row1Struct row1 = new row1Struct();
				load_FCT_Sales_Invoice_LineitemStruct load_FCT_Sales_Invoice_Lineitem = new load_FCT_Sales_Invoice_LineitemStruct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0,
						"load_FCT_Sales_Invoice_Lineitem");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"10.110.243.138\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"Iowa_Liquor_Sales_DIM\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"SA\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:ozh8AyPNqaHCQZ4L046EEWDf7nx1Vj9TFMYoMy/SoVrp8FGxe4/+wtmy")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1
									.append("TABLE" + " = " + "\"fct_iowa_liquor_sales_invoice_lineitem\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "TRUNCATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IDENTITY_INSERT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT_OR_UPDATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "\"fct_iowa_liquor_sales_invoice_lineitem\"", "tMSSqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;
				String dbschema_tDBOutput_1 = null;
				String tableName_tDBOutput_1 = null;
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				long year1_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "0001-01-01").getTime();
				long year2_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd", "1753-01-01").getTime();
				long year10000_tDBOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss", "9999-12-31 24:00:00")
						.getTime();
				long date_tDBOutput_1;

				java.util.Calendar calendar_datetimeoffset_tDBOutput_1 = java.util.Calendar
						.getInstance(java.util.TimeZone.getTimeZone("UTC"));

				int updateKeyCount_tDBOutput_1 = 1;
				if (updateKeyCount_tDBOutput_1 < 1) {
					throw new RuntimeException("For update, Schema must have a key");
				} else if (updateKeyCount_tDBOutput_1 == 15 && true) {
					log.warn("For update, every Schema column can not be a key");
				}

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbUser_tDBOutput_1 = null;
				dbschema_tDBOutput_1 = "";
				String driverClass_tDBOutput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				java.lang.Class.forName(driverClass_tDBOutput_1);
				String port_tDBOutput_1 = "1433";
				String dbname_tDBOutput_1 = "Iowa_Liquor_Sales_DIM";
				String url_tDBOutput_1 = "jdbc:sqlserver://" + "10.110.243.138";
				if (!"".equals(port_tDBOutput_1)) {
					url_tDBOutput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBOutput_1)) {
					url_tDBOutput_1 += ";databaseName=" + "Iowa_Liquor_Sales_DIM";

				}
				url_tDBOutput_1 += ";appName=" + projectName + ";" + "";
				dbUser_tDBOutput_1 = "SA";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:5P67aH2UQDPODqvtTbg8DpkQ9ctQd67RS5il1fwxYqcZughNYTRWwWc8");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);

				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));

				if (dbschema_tDBOutput_1 == null || dbschema_tDBOutput_1.trim().length() == 0) {
					tableName_tDBOutput_1 = "fct_iowa_liquor_sales_invoice_lineitem";
				} else {
					tableName_tDBOutput_1 = dbschema_tDBOutput_1 + "].[" + "fct_iowa_liquor_sales_invoice_lineitem";
				}
				int count_tDBOutput_1 = 0;

				int rsTruncCountNumber_tDBOutput_1 = 0;
				try (java.sql.Statement stmtTruncCount_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					try (java.sql.ResultSet rsTruncCount_tDBOutput_1 = stmtTruncCount_tDBOutput_1
							.executeQuery("SELECT COUNT(1) FROM [" + tableName_tDBOutput_1 + "]")) {
						if (rsTruncCount_tDBOutput_1.next()) {
							rsTruncCountNumber_tDBOutput_1 = rsTruncCount_tDBOutput_1.getInt(1);
						}
					}
				}
				try (java.sql.Statement stmtTrunc_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Truncating") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("'."));
					stmtTrunc_tDBOutput_1.executeUpdate("TRUNCATE TABLE [" + tableName_tDBOutput_1 + "]");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Truncate") + (" table '") + ("[" + tableName_tDBOutput_1 + "]")
								+ ("' has succeeded."));
					deletedCount_tDBOutput_1 += rsTruncCountNumber_tDBOutput_1;
				}
				java.sql.PreparedStatement pstmt_tDBOutput_1 = null;
				java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = null;
				java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = null;
				pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(
						"SELECT COUNT(1) FROM [" + tableName_tDBOutput_1 + "] WHERE [Invoice_Item_Number] = ?");
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);
				String insert_tDBOutput_1 = "INSERT INTO [" + tableName_tDBOutput_1
						+ "] ([Invoice_Number],[Invoice_Number_LineNo],[Invoice_Item_Number],[Item_SK],[Item_Number],[Pack],[Bottle_Volume_ml],[State_Bottle_Cost],[State_Bottle_Retail],[Bottles_Sold],[Sale_Dollars],[Volume_Sold_Liters],[Volume_Sold_Gallons],[DI_JobID],[DI_CreateDate]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				pstmtInsert_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);
				String update_tDBOutput_1 = "UPDATE [" + tableName_tDBOutput_1
						+ "] SET [Invoice_Number] = ?,[Invoice_Number_LineNo] = ?,[Item_SK] = ?,[Item_Number] = ?,[Pack] = ?,[Bottle_Volume_ml] = ?,[State_Bottle_Cost] = ?,[State_Bottle_Retail] = ?,[Bottles_Sold] = ?,[Sale_Dollars] = ?,[Volume_Sold_Liters] = ?,[Volume_Sold_Gallons] = ?,[DI_JobID] = ?,[DI_CreateDate] = ? WHERE [Invoice_Item_Number] = ?";
				pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(update_tDBOutput_1);
				resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row1_tMap_1 = 0;

				int count_row2_tMap_1 = 0;

				int count_row3_tMap_1 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct>) globalMap
						.get("tHash_Lookup_row2"));

				row2Struct row2HashKey = new row2Struct();
				row2Struct row2Default = new row2Struct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct>) globalMap
						.get("tHash_Lookup_row3"));

				row3Struct row3HashKey = new row3Struct();
				row3Struct row3Default = new row3Struct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_load_FCT_Sales_Invoice_Lineitem_tMap_1 = 0;

				load_FCT_Sales_Invoice_LineitemStruct load_FCT_Sales_Invoice_Lineitem_tmp = new load_FCT_Sales_Invoice_LineitemStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				cLabel = "\"stg_iowa_liquor_sales\"";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"10.110.243.138\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"Iowa\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"SA\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:+Df8qlGJwQ6U8+6IV1RxK3/+Uvp+TTKgdRJQtxqzjWRyARUCfGSf20jo")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"stg_iowa_liquor_sales\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT  		stg_iowa_liquor_sales.Invoice_Item_Number, 		stg_iowa_liquor_sales.Item_Number, 		stg_iowa_liquor_sales.Pack, 		stg_iowa_liquor_sales.Bottle_Volume__ml, 		stg_iowa_liquor_sales.State_Bottle_Cost, 		stg_iowa_liquor_sales.State_Bottle_Retail, 		stg_iowa_liquor_sales.Bottles_Sold, 		stg_iowa_liquor_sales.Sale__Dollars, 		stg_iowa_liquor_sales.Volume_Sold__Liters, 		stg_iowa_liquor_sales.Volume_Sold__Gallons FROM	stg_iowa_liquor_sales\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Invoice_Item_Number") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Item_Number") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Pack") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Bottle_Volume__ml") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("State_Bottle_Cost") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("State_Bottle_Retail") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Bottles_Sold") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Sale__Dollars") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Volume_Sold__Liters") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("Volume_Sold__Gallons") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SET_QUERY_TIMEOUT" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "\"stg_iowa_liquor_sales\"", "tMSSqlInput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_1 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_1 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_1, talendToDBArray_tDBInput_1);
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "SA";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:kzgZRQUTM/TLH9kNeE3Wb21c0TG/SUoy4I/6QS0Wv64Y7ryBKsG1n/Ks");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String port_tDBInput_1 = "1433";
				String dbname_tDBInput_1 = "Iowa";
				String url_tDBInput_1 = "jdbc:sqlserver://" + "10.110.243.138";
				if (!"".equals(port_tDBInput_1)) {
					url_tDBInput_1 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_1)) {
					url_tDBInput_1 += ";databaseName=" + "Iowa";
				}
				url_tDBInput_1 += ";appName=" + projectName + ";" + "";
				String dbschema_tDBInput_1 = "";

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT \n		stg_iowa_liquor_sales.Invoice_Item_Number,\n		stg_iowa_liquor_sales.Item_Number,\n		stg_iowa_liquor_sales.Pack,"
						+ "\n		stg_iowa_liquor_sales.Bottle_Volume__ml,\n		stg_iowa_liquor_sales.State_Bottle_Cost,\n		stg_iowa_liquor_sales.State_Bot"
						+ "tle_Retail,\n		stg_iowa_liquor_sales.Bottles_Sold,\n		stg_iowa_liquor_sales.Sale__Dollars,\n		stg_iowa_liquor_sales.Volume_"
						+ "Sold__Liters,\n		stg_iowa_liquor_sales.Volume_Sold__Gallons\nFROM	stg_iowa_liquor_sales";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.Invoice_Item_Number = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(1);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.Invoice_Item_Number = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.Invoice_Item_Number = tmpContent_tDBInput_1;
								}
							} else {
								row1.Invoice_Item_Number = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.Item_Number = null;
						} else {

							tmpContent_tDBInput_1 = rs_tDBInput_1.getString(2);
							if (tmpContent_tDBInput_1 != null) {
								if (talendToDBList_tDBInput_1.contains(
										rsmd_tDBInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row1.Item_Number = FormatterUtils.formatUnwithE(tmpContent_tDBInput_1);
								} else {
									row1.Item_Number = tmpContent_tDBInput_1;
								}
							} else {
								row1.Item_Number = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.Pack = null;
						} else {

							row1.Pack = rs_tDBInput_1.getInt(3);
							if (rs_tDBInput_1.wasNull()) {
								row1.Pack = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.Bottle_Volume__ml = null;
						} else {

							row1.Bottle_Volume__ml = rs_tDBInput_1.getInt(4);
							if (rs_tDBInput_1.wasNull()) {
								row1.Bottle_Volume__ml = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.State_Bottle_Cost = null;
						} else {

							row1.State_Bottle_Cost = rs_tDBInput_1.getFloat(5);
							if (rs_tDBInput_1.wasNull()) {
								row1.State_Bottle_Cost = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.State_Bottle_Retail = null;
						} else {

							row1.State_Bottle_Retail = rs_tDBInput_1.getFloat(6);
							if (rs_tDBInput_1.wasNull()) {
								row1.State_Bottle_Retail = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.Bottles_Sold = null;
						} else {

							row1.Bottles_Sold = rs_tDBInput_1.getInt(7);
							if (rs_tDBInput_1.wasNull()) {
								row1.Bottles_Sold = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.Sale__Dollars = null;
						} else {

							row1.Sale__Dollars = rs_tDBInput_1.getFloat(8);
							if (rs_tDBInput_1.wasNull()) {
								row1.Sale__Dollars = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.Volume_Sold__Liters = null;
						} else {

							row1.Volume_Sold__Liters = rs_tDBInput_1.getFloat(9);
							if (rs_tDBInput_1.wasNull()) {
								row1.Volume_Sold__Liters = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.Volume_Sold__Gallons = null;
						} else {

							row1.Volume_Sold__Gallons = rs_tDBInput_1.getFloat(10);
							if (rs_tDBInput_1.wasNull()) {
								row1.Volume_Sold__Gallons = null;
							}
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "\"stg_iowa_liquor_sales\"";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "\"stg_iowa_liquor_sales\"";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMap_1 main ] start
						 */

						currentComponent = "tMap_1";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row1", "tDBInput_1", "\"stg_iowa_liquor_sales\"", "tMSSqlInput", "tMap_1", "tMap_1",
								"tMap"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

						row2Struct row2 = null;

						row3Struct row3 = null;

						// ###############################
						// # Input tables (lookups)

						boolean rejectedInnerJoin_tMap_1 = false;
						boolean mainRowRejected_tMap_1 = false;

						///////////////////////////////////////////////
						// Starting Lookup Table "row2"
						///////////////////////////////////////////////

						boolean forceLooprow2 = false;

						row2Struct row2ObjectFromLookup = null;

						if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

							hasCasePrimitiveKeyWithNull_tMap_1 = false;

							row2HashKey.Invoice_Number = row1.Invoice_Item_Number;

							row2HashKey.hashCodeDirty = true;

							tHash_Lookup_row2.lookup(row2HashKey);

						} // G_TM_M_020

						if (tHash_Lookup_row2 != null && tHash_Lookup_row2.getCount(row2HashKey) > 1) { // G 071

							// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row2'
							// and it contains more one result from keys : row2.Invoice_Number = '" +
							// row2HashKey.Invoice_Number + "'");
						} // G 071

						row2Struct fromLookup_row2 = null;
						row2 = row2Default;

						if (tHash_Lookup_row2 != null && tHash_Lookup_row2.hasNext()) { // G 099

							fromLookup_row2 = tHash_Lookup_row2.next();

						} // G 099

						if (fromLookup_row2 != null) {
							row2 = fromLookup_row2;
						}

						///////////////////////////////////////////////
						// Starting Lookup Table "row3"
						///////////////////////////////////////////////

						boolean forceLooprow3 = false;

						row3Struct row3ObjectFromLookup = null;

						if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

							hasCasePrimitiveKeyWithNull_tMap_1 = false;

							row3HashKey.Item_Number = row1.Item_Number;

							row3HashKey.hashCodeDirty = true;

							tHash_Lookup_row3.lookup(row3HashKey);

						} // G_TM_M_020

						if (tHash_Lookup_row3 != null && tHash_Lookup_row3.getCount(row3HashKey) > 1) { // G 071

							// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'row3'
							// and it contains more one result from keys : row3.Item_Number = '" +
							// row3HashKey.Item_Number + "'");
						} // G 071

						row3Struct fromLookup_row3 = null;
						row3 = row3Default;

						if (tHash_Lookup_row3 != null && tHash_Lookup_row3.hasNext()) { // G 099

							fromLookup_row3 = tHash_Lookup_row3.next();

						} // G 099

						if (fromLookup_row3 != null) {
							row3 = fromLookup_row3;
						}

						// ###############################
						{ // start of Var scope

							// ###############################
							// # Vars tables

							Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
							// ###############################
							// # Output tables

							load_FCT_Sales_Invoice_Lineitem = null;

// # Output table : 'load_FCT_Sales_Invoice_Lineitem'
							count_load_FCT_Sales_Invoice_Lineitem_tMap_1++;

							load_FCT_Sales_Invoice_Lineitem_tmp.Invoice_Number = row2.Invoice_Number;
							load_FCT_Sales_Invoice_Lineitem_tmp.Invoice_Number_LineNo = null;
							load_FCT_Sales_Invoice_Lineitem_tmp.Invoice_Item_Number = row1.Invoice_Item_Number;
							load_FCT_Sales_Invoice_Lineitem_tmp.Item_SK = row3.Item_SK;
							load_FCT_Sales_Invoice_Lineitem_tmp.Item_Number = row1.Item_Number;
							load_FCT_Sales_Invoice_Lineitem_tmp.Pack = row1.Pack;
							load_FCT_Sales_Invoice_Lineitem_tmp.Bottle_Volume_ml = null;
							load_FCT_Sales_Invoice_Lineitem_tmp.State_Bottle_Cost = row1.State_Bottle_Cost;
							load_FCT_Sales_Invoice_Lineitem_tmp.State_Bottle_Retail = row1.State_Bottle_Retail;
							load_FCT_Sales_Invoice_Lineitem_tmp.Bottles_Sold = row1.Bottles_Sold;
							load_FCT_Sales_Invoice_Lineitem_tmp.Sale_Dollars = null;
							load_FCT_Sales_Invoice_Lineitem_tmp.Volume_Sold_Liters = null;
							load_FCT_Sales_Invoice_Lineitem_tmp.Volume_Sold_Gallons = null;
							load_FCT_Sales_Invoice_Lineitem_tmp.DI_JobID = pid;
							load_FCT_Sales_Invoice_Lineitem_tmp.DI_CreateDate = TalendDate.getCurrentDate();
							load_FCT_Sales_Invoice_Lineitem = load_FCT_Sales_Invoice_Lineitem_tmp;
							log.debug("tMap_1 - Outputting the record " + count_load_FCT_Sales_Invoice_Lineitem_tMap_1
									+ " of the output table 'load_FCT_Sales_Invoice_Lineitem'.");

// ###############################

						} // end of Var scope

						rejectedInnerJoin_tMap_1 = false;

						tos_count_tMap_1++;

						/**
						 * [tMap_1 main ] stop
						 */

						/**
						 * [tMap_1 process_data_begin ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_begin ] stop
						 */
// Start of branch "load_FCT_Sales_Invoice_Lineitem"
						if (load_FCT_Sales_Invoice_Lineitem != null) {

							/**
							 * [tDBOutput_1 main ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "load_FCT_Sales_Invoice_Lineitem", "tMap_1", "tMap_1", "tMap", "tDBOutput_1",
									"\"fct_iowa_liquor_sales_invoice_lineitem\"", "tMSSqlOutput"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("load_FCT_Sales_Invoice_Lineitem - "
										+ (load_FCT_Sales_Invoice_Lineitem == null ? ""
												: load_FCT_Sales_Invoice_Lineitem.toLogString()));
							}

							whetherReject_tDBOutput_1 = false;

							if (load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number == null) {
								pstmt_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
							} else {
								pstmt_tDBOutput_1.setString(1, load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number);
							}

							int checkCount_tDBOutput_1 = -1;
							try (java.sql.ResultSet rs_tDBOutput_1 = pstmt_tDBOutput_1.executeQuery()) {
								while (rs_tDBOutput_1.next()) {
									checkCount_tDBOutput_1 = rs_tDBOutput_1.getInt(1);
								}
							}
							if (checkCount_tDBOutput_1 > 0) {
								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Number == null) {
									pstmtUpdate_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
								} else {
									pstmtUpdate_tDBOutput_1.setString(1,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Number);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Number_LineNo == null) {
									pstmtUpdate_tDBOutput_1.setNull(2, java.sql.Types.INTEGER);
								} else {
									pstmtUpdate_tDBOutput_1.setInt(2,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Number_LineNo);
								}

								pstmtUpdate_tDBOutput_1.setInt(3, load_FCT_Sales_Invoice_Lineitem.Item_SK);

								if (load_FCT_Sales_Invoice_Lineitem.Item_Number == null) {
									pstmtUpdate_tDBOutput_1.setNull(4, java.sql.Types.VARCHAR);
								} else {
									pstmtUpdate_tDBOutput_1.setString(4, load_FCT_Sales_Invoice_Lineitem.Item_Number);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Pack == null) {
									pstmtUpdate_tDBOutput_1.setNull(5, java.sql.Types.INTEGER);
								} else {
									pstmtUpdate_tDBOutput_1.setInt(5, load_FCT_Sales_Invoice_Lineitem.Pack);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Bottle_Volume_ml == null) {
									pstmtUpdate_tDBOutput_1.setNull(6, java.sql.Types.INTEGER);
								} else {
									pstmtUpdate_tDBOutput_1.setInt(6, load_FCT_Sales_Invoice_Lineitem.Bottle_Volume_ml);
								}

								if (load_FCT_Sales_Invoice_Lineitem.State_Bottle_Cost == null) {
									pstmtUpdate_tDBOutput_1.setNull(7, java.sql.Types.FLOAT);
								} else {
									pstmtUpdate_tDBOutput_1.setFloat(7,
											load_FCT_Sales_Invoice_Lineitem.State_Bottle_Cost);
								}

								if (load_FCT_Sales_Invoice_Lineitem.State_Bottle_Retail == null) {
									pstmtUpdate_tDBOutput_1.setNull(8, java.sql.Types.FLOAT);
								} else {
									pstmtUpdate_tDBOutput_1.setFloat(8,
											load_FCT_Sales_Invoice_Lineitem.State_Bottle_Retail);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Bottles_Sold == null) {
									pstmtUpdate_tDBOutput_1.setNull(9, java.sql.Types.INTEGER);
								} else {
									pstmtUpdate_tDBOutput_1.setInt(9, load_FCT_Sales_Invoice_Lineitem.Bottles_Sold);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Sale_Dollars == null) {
									pstmtUpdate_tDBOutput_1.setNull(10, java.sql.Types.FLOAT);
								} else {
									pstmtUpdate_tDBOutput_1.setFloat(10, load_FCT_Sales_Invoice_Lineitem.Sale_Dollars);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Liters == null) {
									pstmtUpdate_tDBOutput_1.setNull(11, java.sql.Types.FLOAT);
								} else {
									pstmtUpdate_tDBOutput_1.setFloat(11,
											load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Liters);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Gallons == null) {
									pstmtUpdate_tDBOutput_1.setNull(12, java.sql.Types.FLOAT);
								} else {
									pstmtUpdate_tDBOutput_1.setFloat(12,
											load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Gallons);
								}

								if (load_FCT_Sales_Invoice_Lineitem.DI_JobID == null) {
									pstmtUpdate_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
								} else {
									pstmtUpdate_tDBOutput_1.setString(13, load_FCT_Sales_Invoice_Lineitem.DI_JobID);
								}

								if (load_FCT_Sales_Invoice_Lineitem.DI_CreateDate != null) {
									pstmtUpdate_tDBOutput_1.setTimestamp(14, new java.sql.Timestamp(
											load_FCT_Sales_Invoice_Lineitem.DI_CreateDate.getTime()));
								} else {
									pstmtUpdate_tDBOutput_1.setNull(14, java.sql.Types.TIMESTAMP);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number == null) {
									pstmtUpdate_tDBOutput_1.setNull(15 + count_tDBOutput_1, java.sql.Types.VARCHAR);
								} else {
									pstmtUpdate_tDBOutput_1.setString(15 + count_tDBOutput_1,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number);
								}

								try {
									int processedCount_tDBOutput_1 = pstmtUpdate_tDBOutput_1.executeUpdate();
									updatedCount_tDBOutput_1 += processedCount_tDBOutput_1;
									rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
									nb_line_tDBOutput_1++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Updating") + (" the record ")
												+ (nb_line_tDBOutput_1) + ("."));
								} catch (java.lang.Exception e) {
									globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
									whetherReject_tDBOutput_1 = true;
									nb_line_tDBOutput_1++;

									log.error("tDBOutput_1 - " + (e.getMessage()));
									System.err.println(e.getMessage());
								}
							} else {
								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Number == null) {
									pstmtInsert_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
								} else {
									pstmtInsert_tDBOutput_1.setString(1,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Number);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Number_LineNo == null) {
									pstmtInsert_tDBOutput_1.setNull(2, java.sql.Types.INTEGER);
								} else {
									pstmtInsert_tDBOutput_1.setInt(2,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Number_LineNo);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number == null) {
									pstmtInsert_tDBOutput_1.setNull(3, java.sql.Types.VARCHAR);
								} else {
									pstmtInsert_tDBOutput_1.setString(3,
											load_FCT_Sales_Invoice_Lineitem.Invoice_Item_Number);
								}

								pstmtInsert_tDBOutput_1.setInt(4, load_FCT_Sales_Invoice_Lineitem.Item_SK);

								if (load_FCT_Sales_Invoice_Lineitem.Item_Number == null) {
									pstmtInsert_tDBOutput_1.setNull(5, java.sql.Types.VARCHAR);
								} else {
									pstmtInsert_tDBOutput_1.setString(5, load_FCT_Sales_Invoice_Lineitem.Item_Number);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Pack == null) {
									pstmtInsert_tDBOutput_1.setNull(6, java.sql.Types.INTEGER);
								} else {
									pstmtInsert_tDBOutput_1.setInt(6, load_FCT_Sales_Invoice_Lineitem.Pack);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Bottle_Volume_ml == null) {
									pstmtInsert_tDBOutput_1.setNull(7, java.sql.Types.INTEGER);
								} else {
									pstmtInsert_tDBOutput_1.setInt(7, load_FCT_Sales_Invoice_Lineitem.Bottle_Volume_ml);
								}

								if (load_FCT_Sales_Invoice_Lineitem.State_Bottle_Cost == null) {
									pstmtInsert_tDBOutput_1.setNull(8, java.sql.Types.FLOAT);
								} else {
									pstmtInsert_tDBOutput_1.setFloat(8,
											load_FCT_Sales_Invoice_Lineitem.State_Bottle_Cost);
								}

								if (load_FCT_Sales_Invoice_Lineitem.State_Bottle_Retail == null) {
									pstmtInsert_tDBOutput_1.setNull(9, java.sql.Types.FLOAT);
								} else {
									pstmtInsert_tDBOutput_1.setFloat(9,
											load_FCT_Sales_Invoice_Lineitem.State_Bottle_Retail);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Bottles_Sold == null) {
									pstmtInsert_tDBOutput_1.setNull(10, java.sql.Types.INTEGER);
								} else {
									pstmtInsert_tDBOutput_1.setInt(10, load_FCT_Sales_Invoice_Lineitem.Bottles_Sold);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Sale_Dollars == null) {
									pstmtInsert_tDBOutput_1.setNull(11, java.sql.Types.FLOAT);
								} else {
									pstmtInsert_tDBOutput_1.setFloat(11, load_FCT_Sales_Invoice_Lineitem.Sale_Dollars);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Liters == null) {
									pstmtInsert_tDBOutput_1.setNull(12, java.sql.Types.FLOAT);
								} else {
									pstmtInsert_tDBOutput_1.setFloat(12,
											load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Liters);
								}

								if (load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Gallons == null) {
									pstmtInsert_tDBOutput_1.setNull(13, java.sql.Types.FLOAT);
								} else {
									pstmtInsert_tDBOutput_1.setFloat(13,
											load_FCT_Sales_Invoice_Lineitem.Volume_Sold_Gallons);
								}

								if (load_FCT_Sales_Invoice_Lineitem.DI_JobID == null) {
									pstmtInsert_tDBOutput_1.setNull(14, java.sql.Types.VARCHAR);
								} else {
									pstmtInsert_tDBOutput_1.setString(14, load_FCT_Sales_Invoice_Lineitem.DI_JobID);
								}

								if (load_FCT_Sales_Invoice_Lineitem.DI_CreateDate != null) {
									pstmtInsert_tDBOutput_1.setTimestamp(15, new java.sql.Timestamp(
											load_FCT_Sales_Invoice_Lineitem.DI_CreateDate.getTime()));
								} else {
									pstmtInsert_tDBOutput_1.setNull(15, java.sql.Types.TIMESTAMP);
								}

								try {
									int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1.executeUpdate();
									insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
									rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
									nb_line_tDBOutput_1++;
									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Inserting") + (" the record ")
												+ (nb_line_tDBOutput_1) + ("."));
								} catch (java.lang.Exception e) {
									globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
									whetherReject_tDBOutput_1 = true;
									nb_line_tDBOutput_1++;

									log.error("tDBOutput_1 - " + (e.getMessage()));
									System.err.println(e.getMessage());
								}
							}
							////////// batch execute by batch size///////
							class LimitBytesHelper_tDBOutput_1 {
								public int limitBytePart1(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
										throws Exception {
									try {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT_OR_UPDATE")
													+ (" batch."));
										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
												break;
											}
											counter += countEach_tDBOutput_1;
										}

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("The ") + ("INSERT_OR_UPDATE")
													+ (" batch execution has succeeded."));
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

										int countSum_tDBOutput_1 = 0;
										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
										}

										log.error("tDBOutput_1 - " + (e.getMessage()));
										System.err.println(e.getMessage());

									}
									return counter;
								}

								public int limitBytePart2(int counter, java.sql.PreparedStatement pstmt_tDBOutput_1)
										throws Exception {
									try {

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT_OR_UPDATE")
													+ (" batch."));
										for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
											if (countEach_tDBOutput_1 == -2 || countEach_tDBOutput_1 == -3) {
												break;
											}
											counter += countEach_tDBOutput_1;
										}

										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("The ") + ("INSERT_OR_UPDATE")
													+ (" batch execution has succeeded."));
									} catch (java.sql.BatchUpdateException e) {
										globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());

										for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
											counter += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
										}

										log.error("tDBOutput_1 - " + (e.getMessage()));
										System.err.println(e.getMessage());

									}
									return counter;
								}
							}

							//////////// commit every////////////

							commitCounter_tDBOutput_1++;
							if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {
								if (rowsToCommitCount_tDBOutput_1 != 0) {

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
												+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
								}
								conn_tDBOutput_1.commit();
								if (rowsToCommitCount_tDBOutput_1 != 0) {

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
									rowsToCommitCount_tDBOutput_1 = 0;
								}
								commitCounter_tDBOutput_1 = 0;
							}

							tos_count_tDBOutput_1++;

							/**
							 * [tDBOutput_1 main ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_begin ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

							/**
							 * [tDBOutput_1 process_data_begin ] stop
							 */

							/**
							 * [tDBOutput_1 process_data_end ] start
							 */

							currentComponent = "tDBOutput_1";

							cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

							/**
							 * [tDBOutput_1 process_data_end ] stop
							 */

						} // End of branch "load_FCT_Sales_Invoice_Lineitem"

						/**
						 * [tMap_1 process_data_end ] start
						 */

						currentComponent = "tMap_1";

						/**
						 * [tMap_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "\"stg_iowa_liquor_sales\"";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "\"stg_iowa_liquor_sales\"";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_row2 != null) {
					tHash_Lookup_row2.endGet();
				}
				globalMap.remove("tHash_Lookup_row2");

				if (tHash_Lookup_row3 != null) {
					tHash_Lookup_row3.endGet();
				}
				globalMap.remove("tHash_Lookup_row3");

// ###############################      
				log.debug("tMap_1 - Written records count in the table 'load_FCT_Sales_Invoice_Lineitem': "
						+ count_load_FCT_Sales_Invoice_Lineitem_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tDBInput_1", "\"stg_iowa_liquor_sales\"", "tMSSqlInput", "tMap_1", "tMap_1", "tMap",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

				if (pstmtUpdate_tDBOutput_1 != null) {
					pstmtUpdate_tDBOutput_1.close();
					resourceMap.remove("pstmtUpdate_tDBOutput_1");
				}
				if (pstmtInsert_tDBOutput_1 != null) {
					pstmtInsert_tDBOutput_1.close();
					resourceMap.remove("pstmtInsert_tDBOutput_1");
				}
				if (pstmt_tDBOutput_1 != null) {
					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");
				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
								+ (rowsToCommitCount_tDBOutput_1) + (" record(s)."));
				}
				conn_tDBOutput_1.commit();
				if (rowsToCommitCount_tDBOutput_1 != 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
					rowsToCommitCount_tDBOutput_1 = 0;
				}
				commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("updated") + (" ") + (nb_line_update_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId,
						"load_FCT_Sales_Invoice_Lineitem", 2, 0, "tMap_1", "tMap_1", "tMap", "tDBOutput_1",
						"\"fct_iowa_liquor_sales_invoice_lineitem\"", "tMSSqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row2");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_row3");

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				cLabel = "\"stg_iowa_liquor_sales\"";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "\"fct_iowa_liquor_sales_invoice_lineitem\"";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
						if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmtUpdate_tDBOutput_1")) != null) {
							pstmtUpdateToClose_tDBOutput_1.close();
						}
						java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
						if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmtInsert_tDBOutput_1")) != null) {
							pstmtInsertToClose_tDBOutput_1.close();
						}
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public static class row2Struct implements routines.system.IPersistableComparableLookupRow<row2Struct> {
		final static byte[] commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		static byte[] commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public String Invoice_Number;

		public String getInvoice_Number() {
			return this.Invoice_Number;
		}

		public Boolean Invoice_NumberIsNullable() {
			return false;
		}

		public Boolean Invoice_NumberIsKey() {
			return true;
		}

		public Integer Invoice_NumberLength() {
			return 24;
		}

		public Integer Invoice_NumberPrecision() {
			return 0;
		}

		public String Invoice_NumberDefault() {

			return null;

		}

		public String Invoice_NumberComment() {

			return "";

		}

		public String Invoice_NumberPattern() {

			return "";

		}

		public String Invoice_NumberOriginalDbColumnName() {

			return "Invoice_Number";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.Invoice_Number == null) ? 0 : this.Invoice_Number.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row2Struct other = (row2Struct) obj;

			if (this.Invoice_Number == null) {
				if (other.Invoice_Number != null)
					return false;

			} else if (!this.Invoice_Number.equals(other.Invoice_Number))

				return false;

			return true;
		}

		public void copyDataTo(row2Struct other) {

			other.Invoice_Number = this.Invoice_Number;

		}

		public void copyKeysDataTo(row2Struct other) {

			other.Invoice_Number = this.Invoice_Number;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Number = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Invoice_Number = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Invoice_Number, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Invoice_Number, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

			}

			finally {
			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

			}

			finally {
			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

			} finally {
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

			} finally {
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Invoice_Number=" + Invoice_Number);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (Invoice_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Invoice_Number);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.Invoice_Number, other.Invoice_Number);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		org.slf4j.MDC.put("_subJobName", "tDBInput_2");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row2Struct row2 = new row2Struct();

				/**
				 * [tAdvancedHash_row2 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row2", false);
				start_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tAdvancedHash_row2 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tAdvancedHash_row2", "tAdvancedHash_row2", "tAdvancedHash");
					talendJobLogProcess(globalMap);
				}

				// connection name:row2
				// source node:tDBInput_2 - inputs:(after_tDBInput_1) outputs:(row2,row2) |
				// target node:tAdvancedHash_row2 - inputs:(row2) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3)
				// outputs:(load_FCT_Sales_Invoice_Lineitem)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row2 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row2Struct> tHash_Lookup_row2 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row2Struct>getLookup(matchingModeEnum_row2);

				globalMap.put("tHash_Lookup_row2", tHash_Lookup_row2);

				/**
				 * [tAdvancedHash_row2 begin ] stop
				 */

				/**
				 * [tDBInput_2 begin ] start
				 */

				ok_Hash.put("tDBInput_2", false);
				start_Hash.put("tDBInput_2", System.currentTimeMillis());

				currentComponent = "tDBInput_2";

				cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

				int tos_count_tDBInput_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_2 = new StringBuilder();
							log4jParamters_tDBInput_2.append("Parameters:");
							log4jParamters_tDBInput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("HOST" + " = " + "\"10.110.243.138\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("DBNAME" + " = " + "\"Iowa_Liquor_Sales_DIM\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("USER" + " = " + "\"SA\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:LJMYAcguDEDI9BGBpA/sP7GQI4Na5W7L1dS4pcEsyAZ96sxMFZiwfA76")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2
									.append("TABLE" + " = " + "\"fct_iowa_liquor_sales_invoice_header\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("QUERY" + " = "
									+ "\"SELECT fct_iowa_liquor_sales_invoice_header.Invoice_Number FROM	fct_iowa_liquor_sales_invoice_header\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true\"");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("Invoice_Number") + "}]");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("SET_QUERY_TIMEOUT" + " = " + "false");
							log4jParamters_tDBInput_2.append(" | ");
							log4jParamters_tDBInput_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
							log4jParamters_tDBInput_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_2 - " + (log4jParamters_tDBInput_2));
						}
					}
					new BytesLimit65535_tDBInput_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_2", "\"fct_iowa_liquor_sales_invoice_header\"", "tMSSqlInput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_2 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_2 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_2, talendToDBArray_tDBInput_2);
				int nb_line_tDBInput_2 = 0;
				java.sql.Connection conn_tDBInput_2 = null;
				String driverClass_tDBInput_2 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_2 = java.lang.Class.forName(driverClass_tDBInput_2);
				String dbUser_tDBInput_2 = "SA";

				final String decryptedPassword_tDBInput_2 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:ESSSJTfQEWHvQLW234PFFfmL6Xv2ZBuf1lxTuR6Y2lFyO/lCDAv+VLZE");

				String dbPwd_tDBInput_2 = decryptedPassword_tDBInput_2;

				String port_tDBInput_2 = "1433";
				String dbname_tDBInput_2 = "Iowa_Liquor_Sales_DIM";
				String url_tDBInput_2 = "jdbc:sqlserver://" + "10.110.243.138";
				if (!"".equals(port_tDBInput_2)) {
					url_tDBInput_2 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_2)) {
					url_tDBInput_2 += ";databaseName=" + "Iowa_Liquor_Sales_DIM";
				}
				url_tDBInput_2 += ";appName=" + projectName + ";" + "noDatetimeStringSync=true";
				String dbschema_tDBInput_2 = "";

				log.debug("tDBInput_2 - Driver ClassName: " + driverClass_tDBInput_2 + ".");

				log.debug("tDBInput_2 - Connection attempt to '" + url_tDBInput_2 + "' with the username '"
						+ dbUser_tDBInput_2 + "'.");

				conn_tDBInput_2 = java.sql.DriverManager.getConnection(url_tDBInput_2, dbUser_tDBInput_2,
						dbPwd_tDBInput_2);
				log.debug("tDBInput_2 - Connection to '" + url_tDBInput_2 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_2 = conn_tDBInput_2.createStatement();

				String dbquery_tDBInput_2 = "SELECT fct_iowa_liquor_sales_invoice_header.Invoice_Number\nFROM	fct_iowa_liquor_sales_invoice_header";

				log.debug("tDBInput_2 - Executing the query: '" + dbquery_tDBInput_2 + "'.");

				globalMap.put("tDBInput_2_QUERY", dbquery_tDBInput_2);
				java.sql.ResultSet rs_tDBInput_2 = null;

				try {
					rs_tDBInput_2 = stmt_tDBInput_2.executeQuery(dbquery_tDBInput_2);
					java.sql.ResultSetMetaData rsmd_tDBInput_2 = rs_tDBInput_2.getMetaData();
					int colQtyInRs_tDBInput_2 = rsmd_tDBInput_2.getColumnCount();

					String tmpContent_tDBInput_2 = null;

					log.debug("tDBInput_2 - Retrieving records from the database.");

					while (rs_tDBInput_2.next()) {
						nb_line_tDBInput_2++;

						if (colQtyInRs_tDBInput_2 < 1) {
							row2.Invoice_Number = null;
						} else {

							tmpContent_tDBInput_2 = rs_tDBInput_2.getString(1);
							if (tmpContent_tDBInput_2 != null) {
								if (talendToDBList_tDBInput_2.contains(
										rsmd_tDBInput_2.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
									row2.Invoice_Number = FormatterUtils.formatUnwithE(tmpContent_tDBInput_2);
								} else {
									row2.Invoice_Number = tmpContent_tDBInput_2;
								}
							} else {
								row2.Invoice_Number = null;
							}
						}

						log.debug("tDBInput_2 - Retrieving the record " + nb_line_tDBInput_2 + ".");

						/**
						 * [tDBInput_2 begin ] stop
						 */

						/**
						 * [tDBInput_2 main ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

						tos_count_tDBInput_2++;

						/**
						 * [tDBInput_2 main ] stop
						 */

						/**
						 * [tDBInput_2 process_data_begin ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

						/**
						 * [tDBInput_2 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row2 main ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row2", "tDBInput_2", "\"fct_iowa_liquor_sales_invoice_header\"", "tMSSqlInput",
								"tAdvancedHash_row2", "tAdvancedHash_row2", "tAdvancedHash"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
						}

						row2Struct row2_HashRow = new row2Struct();

						row2_HashRow.Invoice_Number = row2.Invoice_Number;

						tHash_Lookup_row2.put(row2_HashRow);

						tos_count_tAdvancedHash_row2++;

						/**
						 * [tAdvancedHash_row2 main ] stop
						 */

						/**
						 * [tAdvancedHash_row2 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						/**
						 * [tAdvancedHash_row2 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row2 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row2";

						/**
						 * [tAdvancedHash_row2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 process_data_end ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

						/**
						 * [tDBInput_2 process_data_end ] stop
						 */

						/**
						 * [tDBInput_2 end ] start
						 */

						currentComponent = "tDBInput_2";

						cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

					}
				} finally {
					if (rs_tDBInput_2 != null) {
						rs_tDBInput_2.close();
					}
					if (stmt_tDBInput_2 != null) {
						stmt_tDBInput_2.close();
					}
					if (conn_tDBInput_2 != null && !conn_tDBInput_2.isClosed()) {

						log.debug("tDBInput_2 - Closing the connection to the database.");

						conn_tDBInput_2.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_2 - Connection to the database closed.");

					}
				}
				globalMap.put("tDBInput_2_NB_LINE", nb_line_tDBInput_2);
				log.debug("tDBInput_2 - Retrieved records count: " + nb_line_tDBInput_2 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_2 - " + ("Done."));

				ok_Hash.put("tDBInput_2", true);
				end_Hash.put("tDBInput_2", System.currentTimeMillis());

				/**
				 * [tDBInput_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_row2 end ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				tHash_Lookup_row2.endPut();

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						"tDBInput_2", "\"fct_iowa_liquor_sales_invoice_header\"", "tMSSqlInput", "tAdvancedHash_row2",
						"tAdvancedHash_row2", "tAdvancedHash", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tAdvancedHash_row2", true);
				end_Hash.put("tAdvancedHash_row2", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_2 finally ] start
				 */

				currentComponent = "tDBInput_2";

				cLabel = "\"fct_iowa_liquor_sales_invoice_header\"";

				/**
				 * [tDBInput_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row2 finally ] start
				 */

				currentComponent = "tAdvancedHash_row2";

				/**
				 * [tAdvancedHash_row2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_2_SUBPROCESS_STATE", 1);
	}

	public static class row3Struct implements routines.system.IPersistableComparableLookupRow<row3Struct> {
		final static byte[] commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		static byte[] commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int Item_SK;

		public int getItem_SK() {
			return this.Item_SK;
		}

		public Boolean Item_SKIsNullable() {
			return false;
		}

		public Boolean Item_SKIsKey() {
			return false;
		}

		public Integer Item_SKLength() {
			return 10;
		}

		public Integer Item_SKPrecision() {
			return 0;
		}

		public String Item_SKDefault() {

			return null;

		}

		public String Item_SKComment() {

			return "";

		}

		public String Item_SKPattern() {

			return "";

		}

		public String Item_SKOriginalDbColumnName() {

			return "Item_SK";

		}

		public String Item_Number;

		public String getItem_Number() {
			return this.Item_Number;
		}

		public Boolean Item_NumberIsNullable() {
			return true;
		}

		public Boolean Item_NumberIsKey() {
			return false;
		}

		public Integer Item_NumberLength() {
			return 10;
		}

		public Integer Item_NumberPrecision() {
			return 0;
		}

		public String Item_NumberDefault() {

			return null;

		}

		public String Item_NumberComment() {

			return "";

		}

		public String Item_NumberPattern() {

			return "";

		}

		public String Item_NumberOriginalDbColumnName() {

			return "Item_Number";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.Item_Number == null) ? 0 : this.Item_Number.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row3Struct other = (row3Struct) obj;

			if (this.Item_Number == null) {
				if (other.Item_Number != null)
					return false;

			} else if (!this.Item_Number.equals(other.Item_Number))

				return false;

			return true;
		}

		public void copyDataTo(row3Struct other) {

			other.Item_SK = this.Item_SK;
			other.Item_Number = this.Item_Number;

		}

		public void copyKeysDataTo(row3Struct other) {

			other.Item_Number = this.Item_Number;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length) {
					if (length < 1024 && commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem.length == 0) {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[1024];
					} else {
						commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length);
				strReturn = new String(commonByteArray_TALEND_ASSIGNMENT_Fact_Invoice_lineitem, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Item_Number = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TALEND_ASSIGNMENT_Fact_Invoice_lineitem) {

				try {

					int length = 0;

					this.Item_Number = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.Item_Number, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.Item_Number, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.Item_SK = dis.readInt();

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.Item_SK = objectIn.readInt();

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				dos.writeInt(this.Item_SK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				objectOut.writeInt(this.Item_SK);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Item_SK=" + String.valueOf(Item_SK));
			sb.append(",Item_Number=" + Item_Number);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Item_SK);

			sb.append("|");

			if (Item_Number == null) {
				sb.append("<null>");
			} else {
				sb.append(Item_Number);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.Item_Number, other.Item_Number);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		org.slf4j.MDC.put("_subJobName", "tDBInput_3");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row3Struct row3 = new row3Struct();

				/**
				 * [tAdvancedHash_row3 begin ] start
				 */

				ok_Hash.put("tAdvancedHash_row3", false);
				start_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_row3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tAdvancedHash_row3 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tAdvancedHash_row3", "tAdvancedHash_row3", "tAdvancedHash");
					talendJobLogProcess(globalMap);
				}

				// connection name:row3
				// source node:tDBInput_3 - inputs:(after_tDBInput_1) outputs:(row3,row3) |
				// target node:tAdvancedHash_row3 - inputs:(row3) outputs:()
				// linked node: tMap_1 - inputs:(row1,row2,row3)
				// outputs:(load_FCT_Sales_Invoice_Lineitem)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_row3 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<row3Struct> tHash_Lookup_row3 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<row3Struct>getLookup(matchingModeEnum_row3);

				globalMap.put("tHash_Lookup_row3", tHash_Lookup_row3);

				/**
				 * [tAdvancedHash_row3 begin ] stop
				 */

				/**
				 * [tDBInput_3 begin ] start
				 */

				ok_Hash.put("tDBInput_3", false);
				start_Hash.put("tDBInput_3", System.currentTimeMillis());

				currentComponent = "tDBInput_3";

				cLabel = "\"Dim_iowa_liquor_Products\"";

				int tos_count_tDBInput_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_3 = new StringBuilder();
							log4jParamters_tDBInput_3.append("Parameters:");
							log4jParamters_tDBInput_3.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("HOST" + " = " + "\"10.110.243.138\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("DRIVER" + " = " + "MSSQL_PROP");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PORT" + " = " + "\"1433\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("DB_SCHEMA" + " = " + "\"\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("DBNAME" + " = " + "\"Iowa_Liquor_Sales_DIM\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("USER" + " = " + "\"SA\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:6nnkrvEzKERHwuITRQyIeHg5moLSdbjezTB1tVACKQ4WCzDlA5TjCxeo")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("TABLE" + " = " + "\"Dim_iowa_liquor_Products\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("QUERY" + " = "
									+ "\"SELECT Dim_iowa_liquor_Products.Item_SK, 		Dim_iowa_liquor_Products.Item_Number FROM	Dim_iowa_liquor_Products\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true\"");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("ACTIVE_DIR_AUTH" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append(
									"TRIM_COLUMN" + " = " + "[{TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Item_SK")
											+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("Item_Number") + "}]");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("SET_QUERY_TIMEOUT" + " = " + "false");
							log4jParamters_tDBInput_3.append(" | ");
							log4jParamters_tDBInput_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlInput");
							log4jParamters_tDBInput_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_3 - " + (log4jParamters_tDBInput_3));
						}
					}
					new BytesLimit65535_tDBInput_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_3", "\"Dim_iowa_liquor_Products\"", "tMSSqlInput");
					talendJobLogProcess(globalMap);
				}

				org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tDBInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory
						.getMSSqlGenerateTimestampUtil();

				java.util.List<String> talendToDBList_tDBInput_3 = new java.util.ArrayList();
				String[] talendToDBArray_tDBInput_3 = new String[] { "FLOAT", "NUMERIC", "NUMERIC IDENTITY", "DECIMAL",
						"DECIMAL IDENTITY", "REAL" };
				java.util.Collections.addAll(talendToDBList_tDBInput_3, talendToDBArray_tDBInput_3);
				int nb_line_tDBInput_3 = 0;
				java.sql.Connection conn_tDBInput_3 = null;
				String driverClass_tDBInput_3 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
				java.lang.Class jdbcclazz_tDBInput_3 = java.lang.Class.forName(driverClass_tDBInput_3);
				String dbUser_tDBInput_3 = "SA";

				final String decryptedPassword_tDBInput_3 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:KppsBz8FIeAr4CLT/ikSiaAkq/2t2O2Pv37ZRYxGyxDN7mzTkITjciEl");

				String dbPwd_tDBInput_3 = decryptedPassword_tDBInput_3;

				String port_tDBInput_3 = "1433";
				String dbname_tDBInput_3 = "Iowa_Liquor_Sales_DIM";
				String url_tDBInput_3 = "jdbc:sqlserver://" + "10.110.243.138";
				if (!"".equals(port_tDBInput_3)) {
					url_tDBInput_3 += ":" + "1433";
				}
				if (!"".equals(dbname_tDBInput_3)) {
					url_tDBInput_3 += ";databaseName=" + "Iowa_Liquor_Sales_DIM";
				}
				url_tDBInput_3 += ";appName=" + projectName + ";" + "noDatetimeStringSync=true";
				String dbschema_tDBInput_3 = "";

				log.debug("tDBInput_3 - Driver ClassName: " + driverClass_tDBInput_3 + ".");

				log.debug("tDBInput_3 - Connection attempt to '" + url_tDBInput_3 + "' with the username '"
						+ dbUser_tDBInput_3 + "'.");

				conn_tDBInput_3 = java.sql.DriverManager.getConnection(url_tDBInput_3, dbUser_tDBInput_3,
						dbPwd_tDBInput_3);
				log.debug("tDBInput_3 - Connection to '" + url_tDBInput_3 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_3 = conn_tDBInput_3.createStatement();

				String dbquery_tDBInput_3 = "SELECT Dim_iowa_liquor_Products.Item_SK,\n		Dim_iowa_liquor_Products.Item_Number\nFROM	Dim_iowa_liquor_Products";

				log.debug("tDBInput_3 - Executing the query: '" + dbquery_tDBInput_3 + "'.");

				globalMap.put("tDBInput_3_QUERY", dbquery_tDBInput_3);
				java.sql.ResultSet rs_tDBInput_3 = null;

				try {
					rs_tDBInput_3 = stmt_tDBInput_3.executeQuery(dbquery_tDBInput_3);
					java.sql.ResultSetMetaData rsmd_tDBInput_3 = rs_tDBInput_3.getMetaData();
					int colQtyInRs_tDBInput_3 = rsmd_tDBInput_3.getColumnCount();

					String tmpContent_tDBInput_3 = null;

					log.debug("tDBInput_3 - Retrieving records from the database.");

					while (rs_tDBInput_3.next()) {
						nb_line_tDBInput_3++;

						if (colQtyInRs_tDBInput_3 < 1) {
							row3.Item_SK = 0;
						} else {

							row3.Item_SK = rs_tDBInput_3.getInt(1);
							if (rs_tDBInput_3.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_3 < 2) {
							row3.Item_Number = null;
						} else {

							tmpContent_tDBInput_3 = rs_tDBInput_3.getString(2);
							if (tmpContent_tDBInput_3 != null) {
								if (talendToDBList_tDBInput_3.contains(
										rsmd_tDBInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
									row3.Item_Number = FormatterUtils.formatUnwithE(tmpContent_tDBInput_3);
								} else {
									row3.Item_Number = tmpContent_tDBInput_3;
								}
							} else {
								row3.Item_Number = null;
							}
						}

						log.debug("tDBInput_3 - Retrieving the record " + nb_line_tDBInput_3 + ".");

						/**
						 * [tDBInput_3 begin ] stop
						 */

						/**
						 * [tDBInput_3 main ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "\"Dim_iowa_liquor_Products\"";

						tos_count_tDBInput_3++;

						/**
						 * [tDBInput_3 main ] stop
						 */

						/**
						 * [tDBInput_3 process_data_begin ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "\"Dim_iowa_liquor_Products\"";

						/**
						 * [tDBInput_3 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row3 main ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "row3", "tDBInput_3", "\"Dim_iowa_liquor_Products\"", "tMSSqlInput",
								"tAdvancedHash_row3", "tAdvancedHash_row3", "tAdvancedHash"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
						}

						row3Struct row3_HashRow = new row3Struct();

						row3_HashRow.Item_SK = row3.Item_SK;

						row3_HashRow.Item_Number = row3.Item_Number;

						tHash_Lookup_row3.put(row3_HashRow);

						tos_count_tAdvancedHash_row3++;

						/**
						 * [tAdvancedHash_row3 main ] stop
						 */

						/**
						 * [tAdvancedHash_row3 process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						/**
						 * [tAdvancedHash_row3 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_row3 process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_row3";

						/**
						 * [tAdvancedHash_row3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 process_data_end ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "\"Dim_iowa_liquor_Products\"";

						/**
						 * [tDBInput_3 process_data_end ] stop
						 */

						/**
						 * [tDBInput_3 end ] start
						 */

						currentComponent = "tDBInput_3";

						cLabel = "\"Dim_iowa_liquor_Products\"";

					}
				} finally {
					if (rs_tDBInput_3 != null) {
						rs_tDBInput_3.close();
					}
					if (stmt_tDBInput_3 != null) {
						stmt_tDBInput_3.close();
					}
					if (conn_tDBInput_3 != null && !conn_tDBInput_3.isClosed()) {

						log.debug("tDBInput_3 - Closing the connection to the database.");

						conn_tDBInput_3.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_3 - Connection to the database closed.");

					}
				}
				globalMap.put("tDBInput_3_NB_LINE", nb_line_tDBInput_3);
				log.debug("tDBInput_3 - Retrieved records count: " + nb_line_tDBInput_3 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_3 - " + ("Done."));

				ok_Hash.put("tDBInput_3", true);
				end_Hash.put("tDBInput_3", System.currentTimeMillis());

				/**
				 * [tDBInput_3 end ] stop
				 */

				/**
				 * [tAdvancedHash_row3 end ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				tHash_Lookup_row3.endPut();

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						"tDBInput_3", "\"Dim_iowa_liquor_Products\"", "tMSSqlInput", "tAdvancedHash_row3",
						"tAdvancedHash_row3", "tAdvancedHash", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tAdvancedHash_row3", true);
				end_Hash.put("tAdvancedHash_row3", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_row3 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_3 finally ] start
				 */

				currentComponent = "tDBInput_3";

				cLabel = "\"Dim_iowa_liquor_Products\"";

				/**
				 * [tDBInput_3 finally ] stop
				 */

				/**
				 * [tAdvancedHash_row3 finally ] start
				 */

				currentComponent = "tAdvancedHash_row3";

				/**
				 * [tAdvancedHash_row3 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_3_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", TalendString.getAsciiRandomString(6));

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
						java.lang.Exception e_talendJobLog = jcm.exception;
						if (e_talendJobLog != null) {
							try (java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();
									java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
								e_talendJobLog.printStackTrace(pw_talendJobLog);
								builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,
										java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
							}
						}

						if (jcm.extra_info != null) {
							builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
						}

						log_context_talendJobLog = builder_talendJobLog
								.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
								.connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label)
								.build();

						auditLogger_talendJobLog.exception(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	private final static java.util.Properties jobInfo = new java.util.Properties();

	public static void main(String[] args) {
		final Fact_Invoice_lineitem Fact_Invoice_lineitemClass = new Fact_Invoice_lineitem();

		int exitCode = Fact_Invoice_lineitemClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Fact_Invoice_lineitem' - Done.");
		}

		System.exit(exitCode);
	}

	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if (path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
		readJobInfo(new java.io.File(BUILD_PATH));
	}

	private void readJobInfo(java.io.File jobInfoFile) {

		if (jobInfoFile.exists()) {
			try {
				jobInfo.load(new java.io.FileInputStream(jobInfoFile));
			} catch (IOException e) {

				log.debug("Read jobInfo.properties file fail: " + e.getMessage());

			}
		}
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s", projectName,
				jobName, jobInfo.getProperty("gitCommitId"), "8.0.1.20220923_1236-patch"));

	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}

		getjobInfo();
		log.info("TalendJob: 'Fact_Invoice_lineitem' - Start.");

		java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
		for (Object jobInfoKey : jobInfoKeys) {
			org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
		}
		org.slf4j.MDC.put("_pid", pid);
		org.slf4j.MDC.put("_rootPid", rootPid);
		org.slf4j.MDC.put("_fatherPid", fatherPid);
		org.slf4j.MDC.put("_projectName", projectName);
		org.slf4j.MDC.put("_startTimestamp", java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC)
				.format(java.time.format.DateTimeFormatter.ISO_INSTANT));
		org.slf4j.MDC.put("_jobRepositoryId", "_T70BoNT7Ee2jcLY6P8Z-BA");
		org.slf4j.MDC.put("_compiledAtTimestamp", "2023-04-07T22:28:20.640963Z");

		java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
		String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
		if (mxNameTable.length == 2) {
			org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
		} else {
			org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
		}

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		org.slf4j.MDC.put("_pid", pid);

		if (rootPid == null) {
			rootPid = pid;
		}

		org.slf4j.MDC.put("_rootPid", rootPid);

		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}
		org.slf4j.MDC.put("_fatherPid", fatherPid);

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		try {
			java.util.Dictionary<String, Object> jobProperties = null;
			if (inOSGi) {
				jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

				if (jobProperties != null && jobProperties.get("context") != null) {
					contextStr = (String) jobProperties.get("context");
				}
			}
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = Fact_Invoice_lineitem.class.getClassLoader().getResourceAsStream(
					"talend_assignment/fact_invoice_lineitem_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = Fact_Invoice_lineitem.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						if (inOSGi && jobProperties != null) {
							java.util.Enumeration<String> keys = jobProperties.keys();
							while (keys.hasMoreElements()) {
								String propKey = keys.nextElement();
								if (defaultProps.containsKey(propKey)) {
									defaultProps.put(propKey, (String) jobProperties.get(propKey));
								}
							}
						}
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, ContextProperties.class, parametersToEncrypt));

		org.slf4j.MDC.put("_context", contextStr);
		log.info("TalendJob: 'Fact_Invoice_lineitem' - Started.");

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : Fact_Invoice_lineitem");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");
		resumeUtil.flush();

		org.slf4j.MDC.remove("_subJobName");
		org.slf4j.MDC.remove("_subJobPid");
		org.slf4j.MDC.remove("_systemPid");
		log.info("TalendJob: 'Fact_Invoice_lineitem' - Finished - status: " + status + " returnCode: " + returnCode);

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 221243 characters generated by Talend Real-time Big Data Platform on the
 * April 7, 2023 at 6:28:20 PM EDT
 ************************************************************************************************/