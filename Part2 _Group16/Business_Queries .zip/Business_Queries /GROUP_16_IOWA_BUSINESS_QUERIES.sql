--LIQUOR SALES MEASURE-- 

--SALES DOLLARS--
select ROUND(sum([Invoice_Sale_Dollars]),2) as 'Liquor Total Sales'
from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h;

--SALES VOLUME GALLON--
select ROUND(sum([Invoice_Volume_Sold_Gallons]),2) as 'Liquor Total Sales Volume In Gallons'
from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h;

--SALES VOLUME BOTTLES--
select ROUND(sum([Invoice_Bottles_Sold]),2) as 'Liquor Total Sales Volume Bottles'
from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h

--GROSS PROFIT RETAIL PRICE - COST --
select ROUND(TotalRetailCost - TotalSalesCost, 2) as 'GrossProfit'
from
(
    select
        sum([State_Bottle_Retail] * [Bottles_Sold]) as 'TotalRetailCost',
        sum([State_Bottle_Cost] * [Bottles_Sold]) as 'TotalSalesCost'
            from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Lineitem] l
            join [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
            on l.[Invoice_Number] = h.[Invoice_Number]
) sq;

--SALES DOLLARS PER CAPITAL--
SELECT YEAR(STR_TO_DATE(h.Invoice_Date, '%m/%d/%Y')) AS Order_Date, y.City, ROUND(SUM(h.Invoice_Sale_Dollars) / y.population, 2) AS Total_Sales
FROM fct_iowa_liquor_sales_invoice_header h, FCT_iowa_city_population_by_year y, Dim_Iowa_Liquor_Stores st
WHERE h.Store_SK = st.Store_SK AND st.City_SK = y.City_SK
GROUP BY Order_Date, y.City
ORDER BY Order_Date, y.City;

--LIQUOR SALES BY TIME--
--TOTAL--
 select ROUND(sum([Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h;

--YEAR--
select YEAR([Invoice_Date]) as 'Year',ROUND(sum([Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 group by YEAR([Invoice_Date])
 order by 1 desc;

--YEAR MONTH--
select YEAR([Invoice_Date]) as 'Year',DATENAME(MONTH, [Invoice_Date]) as 'Month',ROUND(sum([Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 group by YEAR([Invoice_Date]), DATENAME(MONTH, [Invoice_Date])
 order by 1 desc;

--YEAR OVER YEAR (YOY)--
--select top 10 FORMAT(hdr.Invoice_Date,'yyyy') "Year" ,concat('$',sum(itm.Sale_Dollars)) Sales
--from fct_iowa_liquor_sales_invoice_lineitem itm
--join fct_iowa_liquor_sales_invoice_header hdr on (hdr.Invoice_Number=itm.Invoice_Number)
--group by FORMAT(hdr.Invoice_Date,'yyyy')
--order by Sales;

--LIQUOR SALES BY DIMENSION--
--STORE--
select s.[Store_Name] as 'LiquorStoreName',ROUND(sum([Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[Dim_Iowa_Liquor_Stores] s on h.[Store_SK] = s.[Store_SK]
 group by [Store_Name]
 order by 2 desc;

--COUNTY--    
select
 case when g.[County] = '' then 'NOT AVAILABLE'
 else g.[County]
 end as 'CountyName',
 ROUND(sum([Invoice_Sale_Dollars]),2) as 'TotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[Dim_Iowa_Liquor_Stores] s on h.[Store_SK] = s.[Store_SK]
 join (
 select distinct [Geo_SK],[County]
 from [dbo].[Dim_Iowa_Liquor_Geo]
 ) g on s.[Store_SK] = g.[Geo_SK]
 group by [County]
 order by 2 desc;

--CITY--  
select
 case when g.[City] = '' then 'NOT AVAILABLE'
 else g.[City]
 end as 'CityName',
 ROUND(sum([Invoice_Sale_Dollars]),2) as 'TotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[Dim_Iowa_Liquor_Stores] s on h.[Store_SK] = s.[Store_SK]
 join (
 select distinct [Geo_SK],[City]
 from [dbo].[Dim_Iowa_Liquor_Geo]
 ) g on s.[Store_SK] = g.[Geo_SK]
 group by [City]
 order by 2 desc;

--CATEGORY--
select pc.[Category_Name] as 'CategoryName',ROUND(sum(h.[Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Lineitem] l on l.[Invoice_Number] = h.[Invoice_Number]
 join [dbo].[Dim_Iowa_Liquor_Products] p on l.[Item_SK] = p.[Item_SK]
 join [dbo].[Dim_Iowa_Liquor_Product_Categories] pc on pc.[Category_SK] = p.[Category_SK]
 group by pc.[Category_Name]
 order by 2 desc;

--ITEM--
select p.[Item_Description] as 'ItemName',ROUND(sum(h.[Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Lineitem] l on l.[Invoice_Number] = h.[Invoice_Number]
 join [dbo].[Dim_Iowa_Liquor_Products] p on l.[Item_SK] = p.[Item_SK]
 group by p.[Item_Description]
 order by 2 desc;

--VENDOR-- 
select v.[Vendor_Name] as 'VendorName',ROUND(sum(h.[Invoice_Sale_Dollars]),2) as 'LiquorTotalSales'
 from [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Header] h
 join [dbo].[FCT_Iowa_Liquor_Sales_Invoice_Lineitem] l on l.[Invoice_Number] = h.[Invoice_Number]
 join [dbo].[Dim_Iowa_Liquor_Products] p on l.[Item_SK] = p.[Item_SK]
 join [dbo].[Dim_Iowa_Liquor_Vendors] v on p.[Vendor_SK] = v.[Vendor_SK]
 group by v.[Vendor_Name]
 order by 2 desc;



